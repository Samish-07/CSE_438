enum MenuState { home, favourite, message, profile }
